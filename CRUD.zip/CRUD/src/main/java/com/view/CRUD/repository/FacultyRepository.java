package com.view.CRUD.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.view.CRUD.model.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty, Integer>{

}